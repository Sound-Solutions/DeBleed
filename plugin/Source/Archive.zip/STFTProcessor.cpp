#include "STFTProcessor.h"
#include <cmath>

STFTProcessor::STFTProcessor()
{
    // Will be properly initialized in prepare()
}

void STFTProcessor::createWindow()
{
    // Create Hann window for current FFT size
    analysisWindow.resize(currentFFTSize);
    synthesisWindow.resize(currentFFTSize);

    for (int i = 0; i < currentFFTSize; ++i)
    {
        float w = 0.5f * (1.0f - std::cos(2.0f * juce::MathConstants<float>::pi * i / (currentFFTSize - 1)));
        analysisWindow[i] = w;
        synthesisWindow[i] = w;
    }

    // COLA normalization factor for Hann with 50% overlap
    colaSum = 1.5f;
}

void STFTProcessor::prepare(double sampleRate, int maxBlockSize)
{
    currentSampleRate = sampleRate;

    // Set FFT parameters based on mode
    if (mode == Mode::LowLatency)
    {
        currentFFTSize = N_FFT_LOW_LATENCY;
        currentHopLength = HOP_LOW_LATENCY;
    }
    else
    {
        currentFFTSize = N_FFT_QUALITY;
        currentHopLength = HOP_QUALITY;
    }

    currentFreqBins = currentFFTSize / 2 + 1;

    // Create FFT
    fftOrder = static_cast<int>(std::log2(currentFFTSize));
    fft = std::make_unique<juce::dsp::FFT>(fftOrder);

    // Create windows
    createWindow();

    // Calculate maximum number of frames per block
    maxFrames = (maxBlockSize / currentHopLength) + 4;

    // Allocate buffers
    inputBuffer.resize(currentFFTSize, 0.0f);
    inputWritePos = 0;

    // Magnitude/phase buffers - always N_FREQ_BINS (129) for neural net compatibility
    magnitudeBuffer.resize(N_FREQ_BINS * maxFrames, 0.0f);
    phaseBuffer.resize(N_FREQ_BINS * maxFrames, 0.0f);
    numFramesReady = 0;

    // Output buffer - larger to handle circular wrap-around safely
    outputBuffer.resize(currentFFTSize * 8 + maxBlockSize, 0.0f);
    outputReadPos = 0;
    outputWritePos = 0;

    // FFT work buffer
    fftWorkBuffer.resize(currentFFTSize * 2, 0.0f);

    // Interpolation buffers for low-latency mode
    if (mode == Mode::LowLatency)
    {
        interpMagBuffer.resize(N_FREQ_BINS, 0.0f);
        interpPhaseBuffer.resize(N_FREQ_BINS, 0.0f);
        decimatedMaskBuffer.resize(currentFreqBins, 0.0f);
    }
}

void STFTProcessor::reset()
{
    std::fill(inputBuffer.begin(), inputBuffer.end(), 0.0f);
    inputWritePos = 0;

    std::fill(magnitudeBuffer.begin(), magnitudeBuffer.end(), 0.0f);
    std::fill(phaseBuffer.begin(), phaseBuffer.end(), 0.0f);
    numFramesReady = 0;

    std::fill(outputBuffer.begin(), outputBuffer.end(), 0.0f);
    outputReadPos = 0;
    outputWritePos = 0;
}

int STFTProcessor::processBlock(const float* input, int numSamples)
{
    numFramesReady = 0;

    for (int i = 0; i < numSamples; ++i)
    {
        inputBuffer[inputWritePos] = input[i];
        inputWritePos++;

        if (inputWritePos >= currentFFTSize)
        {
            computeSTFTFrame(inputBuffer.data());

            std::memmove(inputBuffer.data(),
                        inputBuffer.data() + currentHopLength,
                        (currentFFTSize - currentHopLength) * sizeof(float));
            inputWritePos = currentFFTSize - currentHopLength;
        }
    }

    return numFramesReady;
}

void STFTProcessor::interpolateBins(const float* input, int inputBins, float* output, int outputBins)
{
    // Linear interpolation from inputBins to outputBins
    for (int i = 0; i < outputBins; ++i)
    {
        float srcPos = static_cast<float>(i) * (inputBins - 1) / (outputBins - 1);
        int srcIdx = static_cast<int>(srcPos);
        float frac = srcPos - srcIdx;

        if (srcIdx >= inputBins - 1)
        {
            output[i] = input[inputBins - 1];
        }
        else
        {
            output[i] = input[srcIdx] * (1.0f - frac) + input[srcIdx + 1] * frac;
        }
    }
}

void STFTProcessor::decimateBins(const float* input, int inputBins, float* output, int outputBins)
{
    // Linear interpolation from inputBins to outputBins (downsampling)
    for (int i = 0; i < outputBins; ++i)
    {
        float srcPos = static_cast<float>(i) * (inputBins - 1) / (outputBins - 1);
        int srcIdx = static_cast<int>(srcPos);
        float frac = srcPos - srcIdx;

        if (srcIdx >= inputBins - 1)
        {
            output[i] = input[inputBins - 1];
        }
        else
        {
            output[i] = input[srcIdx] * (1.0f - frac) + input[srcIdx + 1] * frac;
        }
    }
}

void STFTProcessor::computeSTFTFrame(const float* frameData)
{
    if (numFramesReady >= maxFrames)
        return;

    // Apply analysis window
    for (int i = 0; i < currentFFTSize; ++i)
    {
        fftWorkBuffer[i] = frameData[i] * analysisWindow[i];
    }
    for (int i = currentFFTSize; i < currentFFTSize * 2; ++i)
    {
        fftWorkBuffer[i] = 0.0f;
    }

    // Forward FFT
    fft->performRealOnlyForwardTransform(fftWorkBuffer.data());

    // Extract magnitude and phase to temporary buffers
    std::vector<float> tempMag(currentFreqBins);
    std::vector<float> tempPhase(currentFreqBins);

    // DC component
    tempMag[0] = std::abs(fftWorkBuffer[0]);
    tempPhase[0] = (fftWorkBuffer[0] >= 0) ? 0.0f : juce::MathConstants<float>::pi;

    // Nyquist
    tempMag[currentFreqBins - 1] = std::abs(fftWorkBuffer[1]);
    tempPhase[currentFreqBins - 1] = (fftWorkBuffer[1] >= 0) ? 0.0f : juce::MathConstants<float>::pi;

    // Other bins
    for (int bin = 1; bin < currentFreqBins - 1; ++bin)
    {
        float real = fftWorkBuffer[bin * 2];
        float imag = fftWorkBuffer[bin * 2 + 1];
        tempMag[bin] = std::sqrt(real * real + imag * imag);
        tempPhase[bin] = std::atan2(imag, real);
    }

    // Output pointers (always N_FREQ_BINS = 129)
    float* magPtr = magnitudeBuffer.data() + numFramesReady * N_FREQ_BINS;
    float* phasePtr = phaseBuffer.data() + numFramesReady * N_FREQ_BINS;

    // Interpolate if needed (low-latency mode: 65 bins -> 129 bins)
    if (currentFreqBins != N_FREQ_BINS)
    {
        interpolateBins(tempMag.data(), currentFreqBins, magPtr, N_FREQ_BINS);
        interpolateBins(tempPhase.data(), currentFreqBins, phasePtr, N_FREQ_BINS);
    }
    else
    {
        std::memcpy(magPtr, tempMag.data(), N_FREQ_BINS * sizeof(float));
        std::memcpy(phasePtr, tempPhase.data(), N_FREQ_BINS * sizeof(float));
    }

    numFramesReady++;
}

void STFTProcessor::applyMaskAndReconstruct(const float* mask, float* output, int numSamples)
{
    // Store the raw FFT data during forward pass, then reconstruct directly
    // This tests if the issue is in mag/phase round-trip or in overlap-add timing

    for (int frame = 0; frame < numFramesReady; ++frame)
    {
        // Get the stored magnitude and phase
        const float* magPtr = magnitudeBuffer.data() + frame * N_FREQ_BINS;
        const float* phasePtr = phaseBuffer.data() + frame * N_FREQ_BINS;
        const float* maskPtr = mask + frame * N_FREQ_BINS;

        // Decimate if needed for low-latency mode
        const float* actualMask = maskPtr;
        std::vector<float> reconMag(currentFreqBins);
        std::vector<float> reconPhase(currentFreqBins);

        if (currentFreqBins != N_FREQ_BINS)
        {
            decimateBins(maskPtr, N_FREQ_BINS, decimatedMaskBuffer.data(), currentFreqBins);
            actualMask = decimatedMaskBuffer.data();
            decimateBins(magPtr, N_FREQ_BINS, reconMag.data(), currentFreqBins);
            decimateBins(phasePtr, N_FREQ_BINS, reconPhase.data(), currentFreqBins);
        }
        else
        {
            std::memcpy(reconMag.data(), magPtr, currentFreqBins * sizeof(float));
            std::memcpy(reconPhase.data(), phasePtr, currentFreqBins * sizeof(float));
        }

        // Clear and reconstruct complex spectrum
        std::fill(fftWorkBuffer.begin(), fftWorkBuffer.end(), 0.0f);

        // DC
        fftWorkBuffer[0] = reconMag[0] * actualMask[0] * std::cos(reconPhase[0]);

        // Nyquist
        fftWorkBuffer[1] = reconMag[currentFreqBins - 1] * actualMask[currentFreqBins - 1] * std::cos(reconPhase[currentFreqBins - 1]);

        // Complex bins
        for (int bin = 1; bin < currentFreqBins - 1; ++bin)
        {
            float mag = reconMag[bin] * actualMask[bin];
            float phase = reconPhase[bin];
            fftWorkBuffer[bin * 2] = mag * std::cos(phase);
            fftWorkBuffer[bin * 2 + 1] = mag * std::sin(phase);
        }

        // Inverse FFT
        fft->performRealOnlyInverseTransform(fftWorkBuffer.data());

        // Overlap-add into output buffer
        for (int i = 0; i < currentFFTSize; ++i)
        {
            int outIdx = (outputWritePos + i) % outputBuffer.size();
            outputBuffer[outIdx] += fftWorkBuffer[i] * 0.5f;
        }
        outputWritePos = (outputWritePos + currentHopLength) % outputBuffer.size();
    }

    // Read output - but only clear samples that are far enough behind write position
    // to ensure overlap-add is complete
    int safeDistance = currentFFTSize;  // Need at least one full frame of distance

    for (int i = 0; i < numSamples; ++i)
    {
        int readIdx = (outputReadPos + i) % outputBuffer.size();
        float sample = outputBuffer[readIdx];

        if (std::isnan(sample) || std::isinf(sample))
            sample = 0.0f;
        else
            sample = std::clamp(sample, -10.0f, 10.0f);

        output[i] = sample;

        // Only clear if this position is safely behind the write position
        int distance = (outputWritePos - readIdx + outputBuffer.size()) % outputBuffer.size();
        if (distance > safeDistance)
            outputBuffer[readIdx] = 0.0f;
    }

    outputReadPos = (outputReadPos + numSamples) % outputBuffer.size();
}

void STFTProcessor::readOutput(float* output, int numSamples)
{
    // Read from output buffer without processing new frames
    int safeDistance = currentFFTSize;

    for (int i = 0; i < numSamples; ++i)
    {
        int readIdx = (outputReadPos + i) % outputBuffer.size();
        float sample = outputBuffer[readIdx];

        if (std::isnan(sample) || std::isinf(sample))
            sample = 0.0f;
        else
            sample = std::clamp(sample, -10.0f, 10.0f);

        output[i] = sample;

        // Only clear if safely behind write position
        int distance = (outputWritePos - readIdx + outputBuffer.size()) % outputBuffer.size();
        if (distance > safeDistance)
            outputBuffer[readIdx] = 0.0f;
    }

    outputReadPos = (outputReadPos + numSamples) % outputBuffer.size();
}

void STFTProcessor::computeISTFTFrame(const float* magnitude, const float* phase, float* output)
{
    // DC
    fftWorkBuffer[0] = magnitude[0] * std::cos(phase[0]);

    // Nyquist
    fftWorkBuffer[1] = magnitude[currentFreqBins - 1] * std::cos(phase[currentFreqBins - 1]);

    // Other bins
    for (int bin = 1; bin < currentFreqBins - 1; ++bin)
    {
        fftWorkBuffer[bin * 2] = magnitude[bin] * std::cos(phase[bin]);
        fftWorkBuffer[bin * 2 + 1] = magnitude[bin] * std::sin(phase[bin]);
    }

    fft->performRealOnlyInverseTransform(fftWorkBuffer.data());

    for (int i = 0; i < currentFFTSize; ++i)
    {
        output[i] = fftWorkBuffer[i] * synthesisWindow[i];
    }
}
